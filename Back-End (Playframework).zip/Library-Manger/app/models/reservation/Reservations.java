package models.reservation;

import com.fasterxml.jackson.annotation.JsonIgnore;
import models.DateTime;
import models.persons.Reader;

import java.util.ArrayList;
import java.util.List;

public class Reservations {
    private List<Reservation>reservations;

    public Reservations()
    {
        reservations=new ArrayList<>();
    }

    public boolean addReservation(Reader reader,DateTime returnDate,int noOfdays)
    {
        for (Reservation r:reservations)
        {
            if(r.getReader().equals(reader))

                return false;
        }
        DateTime reservationDate= (returnDate==null? new DateTime(): returnDate);//null mean haven't borrowed
        if(reservations.size()!=0)
            reservationDate=DateTime.addDays(reservations.get(reservations.size()-1).getDate(),noOfdays);

        reservations.add(new Reservation(reader,reservationDate));
        return true;
    }

    public boolean removeReservation(Reader reader,int noOfDays) //one user can place multiple reservations
    {
        for(int i=0;i<reservations.size();i++)
        {
            Reservation r=reservations.get(i);
            if(r.getReader().equals(reader))
            {
                Reservation temp=reservations.get(i);
//                reservations.remove(i);
                DateTime reservationDate=temp.getDate();
                for (int j=i+1;j<reservations.size();j++)
                {
                    Reservation edit=reservations.get(j);
                    edit.setDate(reservationDate);
                    DateTime d=DateTime.addDays(reservationDate,noOfDays);
                    reservationDate=d;
                }
//                rewriteReservation(returnDate,noOfDays);
                reservations.remove(i);
                return true;
            }
        }
        return false;

    }

//    private void rewriteReservation(DateTime returnDate,int noOfDays)
//    {
//        DateTime reservationDate=returnDate;
//        for (Reservation reservation:reservations)
//        {
//            reservation.setDate(reservationDate);
//            DateTime d=DateTime.addDays(reservationDate,noOfDays);
//            reservationDate=d;
//        }
//    }

    public List<Reservation> getReservations()
    {
        return reservations;
    }



}
