package models.reservation;

import models.DateTime;
import models.persons.Reader;

public class Reservation {
    private DateTime date;
    private Reader reader;

    public Reservation(Reader reader,DateTime date) {
        this.date = date;
        this.reader = reader;
    }

    public Reservation()
    {

    }

    public DateTime getDate() {
        return date;
    }

    public void setDate(DateTime date) {
        this.date = date;
    }

    public Reader getReader() {
        return reader;
    }

    public void setReader(Reader reader) {
        this.reader = reader;
    }
}
