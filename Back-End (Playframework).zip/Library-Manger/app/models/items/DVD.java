package models.items;


import com.fasterxml.jackson.annotation.JsonIgnore;
import models.DateTime;
import models.persons.Reader;

import java.util.Calendar;
import java.util.List;

public class DVD extends LibraryItem {

    private List<String> w1673657_languages;
    private List<String> w1673657_subtitles;
    private List<String> w1673657_creators;
    private List<String> w1673657_actors;
    private String type="dvd";//for angular

    public DVD()
    {
//for jakcson
    }


    public DVD(String w1673657_isbn, String w1673657_title, String w1673657_sector, String w1673657_publishers,
               List<String> w1673657_languages, List<String> w1673657_subtitles, List<String> w1673657_creators,
               List<String> w1673657_actors) {
        super(w1673657_isbn, w1673657_title, w1673657_sector, w1673657_publishers);
        this.w1673657_languages = w1673657_languages;
        this.w1673657_subtitles = w1673657_subtitles;
        this.w1673657_creators = w1673657_creators;
        this.w1673657_actors = w1673657_actors;
    }

    public List<String> getW1673657_languages() {
        return w1673657_languages;
    }

    public void setW1673657_languages(List<String> w1673657_languages) {
        this.w1673657_languages = w1673657_languages;
    }

    public List<String> getW1673657_subtitles() {
        return w1673657_subtitles;
    }

    public void setW1673657_subtitles(List<String> w1673657_subtitles) {
        this.w1673657_subtitles = w1673657_subtitles;
    }

    public List<String> getW1673657_creators() {
        return w1673657_creators;
    }

    public void setW1673657_creators(List<String> w1673657_creators) {
        this.w1673657_creators = w1673657_creators;
    }

    public List<String> getW1673657_actors() {
        return w1673657_actors;
    }

    public void setW1673657_actors(List<String> w1673657_actors) {
        this.w1673657_actors = w1673657_actors;
    }

    public String getType() {
        return type;
    }


    @Override
    public DateTime getReturnDate()
    {
        if (super.isW1673657_borrowed())
        {
            Calendar cal = Calendar.getInstance();
            cal.set(Calendar.DAY_OF_MONTH, getW1673657_borrowedDate().getDay() );
            cal.set(Calendar.MONTH, getW1673657_borrowedDate().getMonth()-1);
            cal.set(Calendar.YEAR, getW1673657_borrowedDate().getYear());

            cal.add(Calendar.DAY_OF_MONTH,3);
            int year=cal.getTime().getYear()+1900;
            int month=cal.getTime().getMonth()+1;
            int day=cal.getTime().getDate();
            return new DateTime(day,month,year, getW1673657_borrowedDate().getHour(), getW1673657_borrowedDate().getMins());
        }
        return null;
    }

    @Override
    public boolean addReservation(Reader reader){//reservation reader
        return getReservations().addReservation(reader,getReturnDate(),3);
    }

    @Override
    public void removeReservation(Reader reader) {
        getReservations().removeReservation(reader,3);

    }

    @JsonIgnore
    @Override
    public String getAvailableDate()
    {
        if(!isW1673657_borrowed())
            return null;

        if(getReservations().getReservations().size()==0)
            return getReturnDate().getDate();

        return DateTime.addDays(getReservations().getReservations().get(getReservations().getReservations().size()-1)
                .getDate(),3).getDate();
        //return the final date
    }

    @Override
    public String toString()
    {
        String s=super.toString();
//        s+="\nCreator (s) :";
//        for (String x: w1673657_creators)
//                s+="             "+x+"\n";
//        for (String x: w1673657_actors)
//            s+="             "+x+"\n";
//               s+= "Language(s) :"+ w1673657_languages +
//                "\nSubtitle(s) :"+ w1673657_subtitles;
       s+=type;
        return s;
    }
}
