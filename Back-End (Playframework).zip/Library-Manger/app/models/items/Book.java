package models.items;

import com.fasterxml.jackson.annotation.JsonIgnore;
import models.DateTime;
import models.persons.Reader;
import models.reservation.Reservations;

import java.util.Calendar;
import java.util.List;

public class Book extends LibraryItem {
    private List<String> w1673657_authors;
    private int w1673657_noOfPages;
    private String type="book"; //for angular

    public String getType() {
        return type;
    }

    public Book(String isbn, String title, String sector, String publishers, List<String> w1673657_authors,
                int w1673657_noOfPages) {
        super(isbn,title, sector, publishers);
        this.w1673657_authors = w1673657_authors;
        this.w1673657_noOfPages = w1673657_noOfPages;
    }

//    public Book(String w1673657_isbn, String w1673657_title, String w1673657_sector, boolean w1673657_borrowed, //for jackson
//                String w1673657_publishers, Reservations reservations, List<String> w1673657_authors, int w1673657_noOfPages) {
//        super(w1673657_isbn, w1673657_title, w1673657_sector, w1673657_borrowed, w1673657_publishers, reservations);
//        this.w1673657_authors = w1673657_authors;
//        this.w1673657_noOfPages = w1673657_noOfPages;
//    }
    public Book()
    {

    }

    public List<String> getW1673657_authors() {
        return w1673657_authors;
    }

    public void setW1673657_authors(List<String> w1673657_authors) {
        this.w1673657_authors = w1673657_authors;
    }


    public int getW1673657_noOfPages() {
        return w1673657_noOfPages;
    }

    public void setW1673657_noOfPages(int w1673657_noOfPages) {
        this.w1673657_noOfPages = w1673657_noOfPages;
    }

    @Override
    public DateTime getReturnDate()
    {
        if (super.isW1673657_borrowed())
        {
            return DateTime.addDays(super.getW1673657_borrowedDate(),7);
        }
        return null;
    }

    @Override
    public boolean addReservation(Reader reader) {
        //reservation reader
        return getReservations().addReservation(reader,getReturnDate(),7);

    }

    @Override
    public void removeReservation(Reader reader) {
        getReservations().removeReservation(reader,7);
    }

    @JsonIgnore
    @Override
    public String getAvailableDate()
    {
        if (!isW1673657_borrowed())
            return null;
        if(getReservations().getReservations().size()==0)
            return getReturnDate().getDate();

        return DateTime.addDays(getReservations().getReservations().get(getReservations().getReservations().size()-1)
                .getDate(),7).getDate();
        //return the final date
    }

    @Override
    public String toString() {

        String s=super.toString();
//        s+="\nAuthor(s) :";
//        for (String x: w1673657_authors)
//        {
//
//            s+="           "+x+"\n";
//        }

        s+="No of pages :"+ w1673657_noOfPages;
        s+=getType();
        return s;
    }
}
