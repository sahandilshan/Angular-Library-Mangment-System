package models.items;


import com.fasterxml.jackson.annotation.JsonIgnore;
import models.DateTime;
import models.persons.Reader;
import models.reservation.Reservations;

public abstract class LibraryItem {

    private String w1673657_isbn;
    private String w1673657_title;
    private String w1673657_sector;
    private boolean w1673657_borrowed;
    @JsonIgnore
    private DateTime w1673657_borrowedDate;
    @JsonIgnore
    private Reader w1673657_reader;
    private String w1673657_publishers;
    private Reservations reservations;



    public LibraryItem(String w1673657_isbn, String w1673657_title, String w1673657_sector, boolean w1673657_borrowed,
                       DateTime w1673657_borrowedDate, Reader w1673657_reader, String w1673657_publishers) {
        this.w1673657_isbn = w1673657_isbn;//..
        this.w1673657_title = w1673657_title;//..
        this.w1673657_sector = w1673657_sector;//..
        this.w1673657_borrowed = w1673657_borrowed;//..
        this.w1673657_borrowedDate = w1673657_borrowedDate;//..
        this.w1673657_reader = w1673657_reader;//..
        this.w1673657_publishers = w1673657_publishers;//..
        reservations=new Reservations();
    }

    public LibraryItem(String w1673657_isbn, String w1673657_title, String w1673657_sector, String w1673657_publishers) {
        this.w1673657_isbn = w1673657_isbn;
        this.w1673657_title = w1673657_title;
        this.w1673657_sector = w1673657_sector;
        this.w1673657_publishers = w1673657_publishers;
        reservations=new Reservations();
    }

//    public LibraryItem(String w1673657_isbn, String w1673657_title, String w1673657_sector,
//                       boolean w1673657_borrowed, String w1673657_publishers, Reservations reservations) { //for jackson
//        this.w1673657_isbn = w1673657_isbn;
//        this.w1673657_title = w1673657_title;
//        this.w1673657_sector = w1673657_sector;
//        this.w1673657_borrowed = w1673657_borrowed;
//        this.w1673657_publishers = w1673657_publishers;
//        this.reservations = reservations;
//    }
    public LibraryItem()
    {

    }

    public LibraryItem(String isbn)
    {
        this.w1673657_isbn=isbn;
    }

    public String getW1673657_isbn() {
        return w1673657_isbn;
    }

//    public void setW1673657_isbn(String w1673657_isbn) {
//        this.w1673657_isbn = w1673657_isbn;
//    }

    public String getW1673657_title() {
        return w1673657_title;
    }

//    public void setW1673657_title(String w1673657_title) {
//        this.w1673657_title = w1673657_title;
//    }

    public String getW1673657_sector() {
        return w1673657_sector;
    }

//    public void setW1673657_sector(String w1673657_sector) {
//        this.w1673657_sector = w1673657_sector;
//    }
//
//    public void setReservations(Reservations reservations) {
//        this.reservations = reservations;
//    }

    public boolean isW1673657_borrowed() {
        return w1673657_borrowed;
    }

//    public void setW1673657_borrowed(boolean w1673657_borrowed) {
//        this.w1673657_borrowed = w1673657_borrowed;
//    }

    public DateTime getW1673657_borrowedDate() {
        return w1673657_borrowedDate;
    }

    public void setW1673657_borrowedDate(DateTime w1673657_borrowedDate) {
        this.w1673657_borrowedDate = w1673657_borrowedDate;
    }

    public Reader getW1673657_reader() {
        return w1673657_reader;
    }

    public void setW1673657_reader(Reader w1673657_reader) {
        this.w1673657_reader = w1673657_reader;
    }

    public String getW1673657_publishers() {
        return w1673657_publishers;
    }

    public void setW1673657_publishers(String w1673657_publishers) {
        this.w1673657_publishers = w1673657_publishers;
    }

    public void setBorrowedDetails(DateTime borrowedDate, Reader reader)
    {
        w1673657_borrowed =true;//..
        this.w1673657_borrowedDate =borrowedDate;//..
        this.w1673657_reader =reader;//..
    }

    public void clearBorrowedDetails()
    {
        w1673657_borrowed =false;//..
        w1673657_borrowedDate =null;//..
        w1673657_reader =null;//..
    }

    @JsonIgnore
     public String  getBorrowedDetails()//..
    {
        if (w1673657_borrowed)//..
            return "Borrower :"+ w1673657_reader.displayShort()+//..
                    "\nBorrowed Date :"+ w1673657_borrowedDate.getTimeDate();//..
        else
            return "Not borrowed";//..
    }


    @JsonIgnore
    public abstract DateTime getReturnDate();//Both dvd and book class should override this method

    @JsonIgnore
    public abstract boolean addReservation(Reader reader);

    public abstract void removeReservation(Reader reader);

    public Reservations getReservations() {
        return reservations;
    }

    public abstract String getAvailableDate();




    @Override
    public String toString()
    {
        String s="ISBN :"+ w1673657_isbn +"\n" +
                "Title :"+ w1673657_title
                +"\nSector :"+ w1673657_sector +
                "\nPublishers :"+ w1673657_publishers+"\n";
                s+= getBorrowedDetails();
        return s;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        LibraryItem that = (LibraryItem) o;

        return w1673657_isbn != null ? w1673657_isbn.equals(that.w1673657_isbn) : that.w1673657_isbn == null;
    }

    @Override
    public int hashCode() {
        return w1673657_isbn != null ? w1673657_isbn.hashCode() : 0;
    }
}
