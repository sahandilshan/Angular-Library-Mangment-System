package models;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.util.Calendar;
import java.util.Date;

public class DateTime {
    int day,month,year,hour,mins;
    private String timePeriod;


    public DateTime(int day, int month, int year) {
        this.day = day;
        this.month = month;
        this.year = year;
    }


    public DateTime()// default for get current date and Time
    {
        Date now=new Date();
        year=now.getYear()+1900;
        month=now.getMonth()+1;
        day=now.getDate();
        hour=now.getHours();
        mins=now.getMinutes();
        this.timePeriod = hour>12?"pm":"am";
    }



    public DateTime(int day, int month, int year, int hour, int mins) {
        this.day = day;
        this.month = month;
        this.year = year;
        this.hour = hour;
        this.mins = mins;
        this.timePeriod = hour>12?"pm":"am";
    }



    public int getDay() {
        return day;
    }

    public int getMonth() {
        return month;
    }

    public int getYear() {
        return year;
    }


    public int getHour() {
        return hour;
    }


    public int getMins() {
        return mins;
    }


    public String getTimePeriod() {
        return timePeriod;
    }



    @JsonIgnore
    public String getDate()
    {
        String date="";
        if(day<10)
            date+="0"+day;
        else
            date+=day;

        if(month<10)
            date+="/0"+month;
        else
            date+="/"+month;


        return date+"/"+year;

    }

    @JsonIgnore
    public String getTimeDate()
    {
        String dateTime=getDate();
        dateTime+=" ";
        int tempHour=hour>12?hour-12:hour;
        if(tempHour<10)
            dateTime+="0"+tempHour;
        else
            dateTime+=tempHour;

        if(mins<10)
            dateTime+=":0"+mins;
        else
            dateTime+=":"+mins;

        dateTime+=timePeriod;
        return dateTime;
    }



    @JsonIgnore
    public int getHours(DateTime o) //a method to get hours between 2 days
    {
        Date d1=new Date((year-1900),(month-1),day,hour,mins);
        Date d2=new Date((o.year-1900),(o.month-1),o.day,o.hour,o.mins);

        long milisec=d1.getTime()-d2.getTime();
        int hours=(int)(milisec/1000/60/60);
        return hours;
    }

    public static DateTime addDays(DateTime date,int noOfDays)
    {
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.DAY_OF_MONTH, date.getDay() );
        cal.set(Calendar.MONTH, date.getMonth()-1);
        cal.set(Calendar.YEAR,date.getYear());

        cal.add(Calendar.DAY_OF_MONTH,noOfDays);
        int year=cal.getTime().getYear()+1900;
        int month=cal.getTime().getMonth()+1;
        int day=cal.getTime().getDate();
        return new DateTime(day,month,year, date.getHour(), date.getMins());
    }

    public void addDays(int noOfDays)
    {
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.DAY_OF_MONTH, this.day );
        cal.set(Calendar.MONTH, this.month-1);
        cal.set(Calendar.YEAR,this.year);

        cal.add(Calendar.DAY_OF_MONTH,noOfDays);
        year=cal.getTime().getYear()+1900;
        month=cal.getTime().getMonth()+1;
        day=cal.getTime().getDate();
//        return new DateTime(day,month,year, date.getHour(), date.getMins());
    }
}
