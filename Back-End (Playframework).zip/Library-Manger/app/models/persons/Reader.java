package models.persons;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.util.Objects;

public class Reader extends Person{
    private String id;


    public Reader(String id)//only for equal part
    {
        this.id=id;
    }

    public Reader()
    {

    }


    public Reader(String fname, String lname, String mobileNumber, String email,
                  int day, int month, int year, String id) {
        super(fname, lname, mobileNumber, email, day, month, year);
        this.id = id;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }



    @JsonIgnore
    public String displayShort()
    {
        return "id: "+id+
                "\nName :"+super.getW1673657_fname()+" "+super.getW1673657_lname();

    }

    @Override
    public String toString() {
        return "id :" + id+"\n" +
                super.toString();

    }

    @Override
    public boolean equals(Object o) {
        Reader r=(Reader)o;
        return this.id.equals(r.getId());
    }

}
