package models.persons;

import models.DateTime;

import java.util.Objects;

public class Person {
    private String w1673657_fname, w1673657_lname;
    private String w1673657_mobileNumber;
    private String w1673657_email;
    private DateTime w1673657_dob;

    private String name; //only for jackson

    public Person()//only for equals part
    {

    }

    public Person(String w1673657_fname, String w1673657_lname, String w1673657_mobileNumber, String w1673657_email, int day, int month, int year) {
        this.w1673657_fname = w1673657_fname;
        this.w1673657_lname = w1673657_lname;
        this.w1673657_mobileNumber = w1673657_mobileNumber;
        this.w1673657_email = w1673657_email;
        this.w1673657_dob =new DateTime(day, month, year);
    }

    public String getW1673657_fname() {
        return w1673657_fname;
    }

    public void setW1673657_fname(String w1673657_fname) {
        this.w1673657_fname = w1673657_fname;
    }

    public String getW1673657_lname() {
        return w1673657_lname;
    }

    public void setW1673657_lname(String w1673657_lname) {
        this.w1673657_lname = w1673657_lname;
    }

    public String getW1673657_mobileNumber() {
        return w1673657_mobileNumber;
    }

    public void setW1673657_mobileNumber(String w1673657_mobileNumber) {
        this.w1673657_mobileNumber = w1673657_mobileNumber;
    }

    public String getW1673657_email() {
        return w1673657_email;
    }

    public void setW1673657_email(String w1673657_email) {
        this.w1673657_email = w1673657_email;
    }

    public DateTime getW1673657_dob() {
        return w1673657_dob;
    }

    public void setW1673657_dob(DateTime w1673657_dob) {
        this.w1673657_dob = w1673657_dob;
    }

    public String getName()
    {
        return w1673657_fname +" "+ w1673657_lname;
    }

    @Override
    public String toString() {
        return   "Name :" + w1673657_fname +" "+ w1673657_lname + '\n' +
                "Contact No :" + w1673657_mobileNumber + '\n' +
                "e-mail :" + w1673657_email +"\n" +
                "DoB :"+ w1673657_dob.getDate();
    }


}
