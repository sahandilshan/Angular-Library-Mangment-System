package controllers;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import models.items.DVD;
import play.libs.Json;
import play.mvc.Controller;
import play.mvc.Result;
import service.LibraryManager;
import service.WestminsterLibraryManager;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class DvdController extends Controller {

    LibraryManager manger=new WestminsterLibraryManager();

    private DVD getDvdFromBody(JsonNode body)
    {
        String isbn=body.get("isbn").asText();
        String title=body.get("title").asText();
        String publisher=body.get("publisher").asText();
        String sector=body.get("sector").asText();
        List<String>languages=new ArrayList<>();
        List<String>subtitles=new ArrayList<>();
        List<String>creators=new ArrayList<>();
        List<String>actors=new ArrayList<>();
        JsonNode j= body.get("languages");
        j.forEach(
                value ->
                {
                    languages.add(value.asText());
                }
        );
        body.get("subtitles").forEach(
                value -> subtitles.add(value.asText())
        );
        body.get("creators").forEach(
                value -> creators.add(value.asText())
        );
        body.get("actors").forEach(
                value -> actors.add(value.asText())
        );
        return new DVD(isbn,title,sector,publisher,languages,subtitles,creators,actors);
    }

    public Result addDvd()
    {
        JsonNode body=request().body().asJson();
//        System.out.println(body);
        DVD d=getDvdFromBody(body);

        if(manger.find(d.getW1673657_isbn())!=null)
        {
            return status(999, Json.toJson("duplicated primary key"));
        }

        return manger.addItem(d);

    }

    public Result updateDvd()
    {
        JsonNode body=request().body().asJson();
        DVD d=getDvdFromBody(body);

        try
        {
            return manger.updateItem(d);
        }
        catch(IOException e)
        {
            e.printStackTrace();
            return badRequest(Json.toJson("date error"));
        }
    }

    public Result deleteDVD(String isbn)
    {
        return manger.deleteItem(isbn);
    }
}
