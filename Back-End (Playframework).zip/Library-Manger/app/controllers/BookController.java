package controllers;


import com.fasterxml.jackson.databind.JsonNode;
import models.items.Book;


import models.items.DVD;
import play.libs.Json;
import play.mvc.Controller;
import play.mvc.Result;
import service.LibraryManager;
import service.WestminsterLibraryManager;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * This controller contains an action to handle HTTP requests
 * to the application's home page.
 */
public class BookController extends Controller {

    /**
     * An action that renders an HTML page with a welcome message.
     * The configuration in the <code>routes</code> file means that
     * this method will be called when the application receives a
     * <code>GET</code> request with a path of <code>/</code>.
     */


    public static LibraryManager manger=new WestminsterLibraryManager();

    public Result index() {


        return ok();
    }

    private Book getBookFromBody(JsonNode body)
    {
        String isbn = body.get("isbn").asText();
        String title = body.get("title").asText();
        String publisher = body.get("publisher").asText();
        String sector = body.get("sector").asText();
        List<String> authors = new ArrayList<>();
        JsonNode author = body.get("authors");

        int noOfpages = body.get("noOfpages").asInt();
        author.forEach(val ->
        {
            authors.add(val.asText());
        });

        return new Book(isbn, title, sector, publisher, authors, noOfpages);
    }

    public Result addBook() {
        JsonNode body = request().body().asJson();
        Book b=getBookFromBody(body);
        if(manger.find(b.getW1673657_isbn())!=null)
        {
            return status(999, Json.toJson("duplicated primary key"));
        }
        return manger.addItem(b);
    }

    public Result updateBook()
    {
        JsonNode body=request().body().asJson();
        Book b=getBookFromBody(body);
        try {
            return manger.updateItem(b);
        }

        catch (IOException e)
        {
            e.printStackTrace();
            return badRequest(Json.toJson("date error"));
        }

    }

    public Result deleteBook(String isbn)
    {
        return manger.deleteItem(isbn);
    }




//        int id = Integer.parseInt(body.get("id").asText());
//        String name = body.get("name").asText();
//        Test t=new Test(id,name);
//        ObjectMapper mapper=new ObjectMapper();
//        String jsonInString="";
//
//        try {
//            jsonInString = mapper.writeValueAsString(t);
//        }
//        catch (Exception e)
//        {
//            e.printStackTrace();
//        }
//        System.out.println(jsonInString);
//
//        Document document = new Document()
//                .append("id", id)
//                .append("test",jsonInString);

//                .append("name",name);




//        return ok(Json.toJson("done"));


//    public Result updateBook()
//    {
//        JsonNode body=request().body().asJson();
//
//        int id = Integer.parseInt(body.get("id").asText());
//        String name = body.get("name").asText();
//
//        Bson filter = new Document().append("id",id);
//        Bson newValue = new Document().append("name",name);
//        Bson updateOperationDocument = new Document("$set", newValue);
//        collection.updateOne(filter, updateOperationDocument);
//
//
//
//        return ok(Json.toJson(newValue));
//    }

//    public Result deleteBook(int id)
//    {
//        DeleteResult d=
//        collection.deleteOne(Filters.eq("id", id));
//        if (d.getDeletedCount()==1)
//            return ok();
//        else
//            return internalServerError();
//    }



}
