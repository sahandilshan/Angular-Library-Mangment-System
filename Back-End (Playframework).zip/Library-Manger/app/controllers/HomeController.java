package controllers;

import com.fasterxml.jackson.databind.JsonNode;

import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import models.DateTime;
import models.items.Book;
import models.items.DVD;
import models.items.LibraryItem;
import models.persons.Reader;
import play.libs.Json;
import play.mvc.Controller;
import play.mvc.Result;
import service.LibraryManager;
import service.OverDueItem;
import service.WestminsterLibraryManager;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

public class HomeController extends Controller {

    LibraryManager manger=new WestminsterLibraryManager();

    private boolean isLogged;



    public Result login()
    {
        JsonNode body=request().body().asJson();
        String username=body.get("username").asText();
        char [] password=body.get("password").asText().toCharArray();

        System.out.println(body);
        String cUsername="sahan";
        char [] cPassword={'1','2','3','4'};

//        ObjectNode obj=Json.newObject();

        if(cUsername.equals(username) && Arrays.equals(password,cPassword))
        {
//            obj.put("msg","correct");
            isLogged=true;
            return ok(Json.toJson("ok"));
        }
        return status(991);

    }

    public Result checkLogged()
    {
        ObjectNode obj=Json.newObject();
        obj.put("logged",isLogged);
        return ok(obj);
    }

    public Result logout()
    {
        isLogged=false;
        return ok();
    }

    public Result findIsbn(String isbn)
    {
        LibraryItem i = manger.find(isbn);
        if(i!=null)
            return ok(getItemAsNode(i));

        return notFound();
    }



    public Result setBorrowedDetails()
    {
        JsonNode body=request().body().asJson();
//        String type=body.get("type").asText();
        String isbn=body.get("isbn").asText();
        String readerId=body.get("readerId").asText();

        try
        {
            Reader r=manger.findReader(readerId);
            System.out.println("was here");
            return manger.borrowItem(isbn,r);
        }
        catch (Exception e)
        {
            e.printStackTrace();
            return badRequest();
        }


//        return ok();
    }

    public Result getBorrowedDetails(String isbn)
    {


        return manger.getFine(isbn);
    }

    public Result returnItem()throws IOException
    {
        JsonNode body=request().body().asJson();
        String isbn=body.get("isbn").asText();
        return manger.returnItem(isbn);
    }

    public Result generateReport()
    {
        System.out.println("generate");
        List<OverDueItem> overDue=manger.generateReport();

        ArrayNode node=Json.newArray();
        for(OverDueItem o:overDue)
        {
            ObjectNode obj=Json.newObject();
            obj.put("item",getItemAsNode(o.getItem()));
//            System.out.println(o.getItem());
            obj.put("fine",o.getFine());
            System.out.println("Title :"+o.getItem().getW1673657_title());
            System.out.println("ISBN :"+o.getItem().getW1673657_isbn());
            System.out.println(o.getItem().getBorrowedDetails());
            System.out.println("Fine :"+o.getFine());
            node.add(obj);
        }
        System.out.println(overDue.size());
//        System.out.println(node);
        return ok(node);
    }


    public Result findByTitle(String title)
    {
        System.out.println("find by title");
        List<LibraryItem> items=manger.findItemsByTitle(title);

        if(items.size()!=0)
        {

            return ok(Json.toJson(items));
        }
        return status(994);
    }

    public Result setReservation()
    {
        JsonNode body=request().body().asJson();
        String isbn=body.get("isbn").asText();
        String readerId=body.get("readerId").asText();
        try {
            return manger.addReservation(isbn, readerId);
        }
        catch (IOException e)
        {
            return internalServerError();
        }
    }

    public Result removeReservation() {
        JsonNode body = request().body().asJson();
        System.out.println(body);
        String isbn = body.get("isbn").asText();
        String readerId = body.get("readerId").asText();
        try {
            return manger.removeReservation(isbn, readerId);
        } catch (IOException e) {
            return internalServerError();
        }
    }

    public ObjectNode getItemAsNode(LibraryItem i)
    {
        ObjectNode node = Json.newObject();
        node.put("w1673657_isbn",i.getW1673657_isbn());
        node.put("w1673657_title",i.getW1673657_title());
        node.put("w1673657_sector",i.getW1673657_sector());
        node.put("w1673657_borrowed",i.isW1673657_borrowed());
        node.put("w1673657_borrowedDate", i.isW1673657_borrowed()?Json.toJson(i.getW1673657_borrowedDate().getDate())
                        :null);
        node.put("w1673657_returnDate", i.isW1673657_borrowed()?Json.toJson(i.getReturnDate().getDate())
                :null);
        node.put("w1673657_reader",i.isW1673657_borrowed()?Json.toJson(i.getW1673657_reader()):null);

        node.put("w1673657_publishers",i.getW1673657_publishers());
        node.put("reservations",Json.toJson(i.getReservations()));

        node.put("availableDate",i.getAvailableDate());




        if(i instanceof Book) {
            node.put("w1673657_authors",Json.toJson(((Book) i).getW1673657_authors()));
            node.put("w1673657_noOfPages",((Book) i).getW1673657_noOfPages());
            node.put("type",((Book) i).getType());

        }
        else
        {

            node.put("w1673657_languages",Json.toJson(((DVD) i).getW1673657_languages()));
            node.put("w1673657_subtitles",Json.toJson(((DVD) i).getW1673657_subtitles()));
            node.put("w1673657_creators",Json.toJson(((DVD) i).getW1673657_creators()));
            node.put("w1673657_actors",Json.toJson(((DVD) i).getW1673657_actors()));
            node.put("type",((DVD) i).getType());
//            node.put("availableDate",i.getReservations().);
        }
        return node;
    }










}
