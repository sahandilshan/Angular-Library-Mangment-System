package controllers;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import models.persons.Reader;
import play.libs.Json;
import play.mvc.Controller;
import play.mvc.Result;
import service.WestminsterLibraryManager;

import java.io.IOException;

public class ReaderController extends Controller {

    WestminsterLibraryManager manager=new WestminsterLibraryManager();

    public Result getReaderID()
    {
        String readerId=manager.getReaderId();
        ObjectNode node= Json.newObject();
        node.put("id",readerId);
        return ok(node);
    }



    public Result findReader(String readerId)
    {
        Reader r=manager.findReader(readerId);
        if(r!=null)
        {

            return ok(Json.toJson(r));
        }
        else
            return notFound();
    }

    public Result addReader()
    {
        System.out.println("was here--add Reader");
        JsonNode body=request().body().asJson();
        Reader r=getReaderFromBody(body);
        try {
            return manager.addReader(r);
        }
        catch (IOException e)
        {
            return internalServerError();
        }


    }

    public Result updateReader()
    {
        JsonNode body=request().body().asJson();
        Reader r=getReaderFromBody(body);
        try {
            return manager.updateReader(r);
        }
        catch (IOException e)
        {
            return internalServerError();
        }
    }

    public Result removeReader(String readerId)throws IOException
    {
       return manager.removeReader(readerId);
    }

    private Reader getReaderFromBody(JsonNode body)
    {
        String readerId=body.get("readerId").asText();
        String fname=body.get("fname").asText();
        String lname=body.get("lname").asText();
        String dob=body.get("dob").asText();
        String email=body.get("email").asText();
        String contactNo=body.get("contactNo").asText();

        String [] dateArr=dob.split("-");
        int year=Integer.parseInt(dateArr[0]);
        int month=Integer.parseInt(dateArr[1]);
        int day=Integer.parseInt(dateArr[2]);

        System.out.println(dob);
        System.out.println(year+" "+month+" "+day);
        return new Reader(fname,lname,contactNo,email,day,month,year,readerId);

    }
}
