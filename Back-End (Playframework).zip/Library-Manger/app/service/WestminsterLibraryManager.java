package service;



import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import com.mongodb.MongoWriteException;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import com.mongodb.client.result.DeleteResult;
import controllers.HomeController;
import models.DateTime;
import models.items.Book;
import models.items.DVD;
import models.items.LibraryItem;
import models.persons.Reader;
import org.bson.Document;
import org.bson.conversions.Bson;
import play.libs.Json;
import play.mvc.Controller;
import play.mvc.Result;

import java.io.IOException;
import java.util.*;


public class WestminsterLibraryManager extends Controller implements LibraryManager{
    private static List<LibraryItem> items=new ArrayList<>();
    private static int booksCount,dvdCount;
    private static List<Reader> readers;

    private MongoClientURI uri = new MongoClientURI(
            "mongodb://sahan:1234@cluster01-shard-00-00-cwgaj.mongodb.net:27017," +
                    "cluster01-shard-00-01-cwgaj.mongodb.net:27017,cluster01-shard-00-02-cwgaj.mongodb.net:" +
                    "27017/test?ssl=true&replicaSet=Cluster01-shard-0&authSource=admin&retryWrites=true");
    private MongoClient mongo =new MongoClient(uri);
    private MongoDatabase database = mongo.getDatabase("Library");
    private MongoCollection<Document> bookCollection = database.getCollection("Book");
    private MongoCollection<Document> dvdCollection=database.getCollection(("Dvd"));

    private MongoCollection<Document> readerCollection=database.getCollection("Reader");


//    private MongoCollection<Document> test=database.getCollection("Test");


    private ObjectMapper mapper=new ObjectMapper();

    public Result getAllItems()
    {
        System.out.println("was here---get all");
        readers =new ArrayList<>();
        booksCount=0;
        dvdCount=0;
        items=new ArrayList<>();


        FindIterable<Document> books = bookCollection.find();
        FindIterable<Document> dvd = dvdCollection.find();
        FindIterable<Document>readers=readerCollection.find();
        try {

            for(Document reader:readers)
            {
                String readerJson=reader.getString("reader");
                Reader r=mapper.readValue(readerJson,Reader.class);

                this.readers.add(r);
            }
            getItems(books, "book");
            getItems(dvd, "dvd");

        }catch (IOException e)
        {
            e.printStackTrace();
            return internalServerError();
        }



        System.out.println(items.size());
//        System.out.println(items);


        return ok(Json.toJson(Json.toJson(items)));



    }

    private void getItems(FindIterable<Document> list,String type)throws IOException
    {
        for(Document d:list)
        {
//            String isbn=d.getString("isbn");
            String jsonString=d.getString(type);
            String date=d.getString("borrowedDate");
            String readerId=d.getString("readerId");
            int index=-1;
            if(readerId!=null)
                index = readers.indexOf(new Reader(readerId));//only need id to check the readers

            Reader reader=null;
            if (index!=-1)
                reader=readers.get(index);

                LibraryItem i;
                if(type.equals("book")) {
                    i = mapper.readValue(jsonString, Book.class);
                    booksCount++;
                }
                else {
                    i= mapper.readValue(jsonString, DVD.class);
                    dvdCount++;
                }
                DateTime dateTime=null;
                if(date!=null) {
                    dateTime = mapper.readValue(date, DateTime.class);
                }
                i.setW1673657_borrowedDate(dateTime);
                i.setW1673657_reader(reader);
                items.add(i);



        }
    }

    @Override
    public Result addItem(LibraryItem i) {


        String jsonInString = "";

        try {
            jsonInString = mapper.writeValueAsString(i);
//            Book b=mapper.readValue(jsonInString, Book.class);
            DVD b=mapper.readValue(jsonInString, DVD.class);
            System.out.println(b);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        if(i instanceof Book)
        {
            if(booksCount<100)
            {
                System.out.println(jsonInString);
                Document document = new Document()
                        .append("isbn", i.getW1673657_isbn())
                        .append("book",jsonInString)
                        .append("readerId",null)
                        .append("borrowedDate",null);
                try {
                    bookCollection.insertOne(document);
                    items.add(i);
                    booksCount++;
                }
                catch (MongoWriteException e)
                {
                    if(e.getCode()==11000)
                    {

                        return status(999, Json.toJson("duplicated primary key"));
                    }

                }

            }
            else {

                return status(998, Json.toJson("Maximum book"));
            }
        }
        else
        {
            if(dvdCount<50)
            {
//                DVD d=mapper.readValue(jsonInString,DVD.class)
                System.out.println(jsonInString);
                Document document = new Document()
                        .append("isbn", i.getW1673657_isbn())
                        .append("dvd",jsonInString)
                        .append("readerId",null)
                        .append("borrowedDate",null);
                try {
                    dvdCollection.insertOne(document);
                    items.add(i);
                    dvdCount++;
                }
                catch (MongoWriteException e)
                {
                    if(e.getCode()==11000)
                    {

                        return status(999, Json.toJson("duplicated primary key"));
                    }
                    System.out.println(e.getCode());
                }

            }
            else {

                return status(998, Json.toJson("Maximum DVD"));

            }
        }

        ObjectNode node=Json.newObject();
        node.put("msg","added");
        node.put("bookCount",booksCount);
        node.put("dvdCount",dvdCount);
        return ok(node);
    }

    @Override
    public Result deleteItem(String isbn) {
        LibraryItem i=find(isbn);
        if(i!=null)
        {
            if(!i.isW1673657_borrowed()) {
                items.remove(i);
                if (i instanceof Book) {
                    booksCount--;
                    System.out.println("Book has been removed successfully");
                    System.out.println("Free spaces left in books :" + (100 - booksCount));
                    ObjectNode obj = Json.newObject();
                    obj.put("msg", "deleted");
                    obj.put("freespace", 100 - booksCount);

                    deleteFromCollection(isbn,bookCollection);

//                obj.put("dvdCount",dvdCount);
                    return ok(obj);
                } else {
                    dvdCount--;
                    System.out.println("DVD has been removed successfully");
                    System.out.println("Free spaces left in DVDs :" + (50 - dvdCount));
                    ObjectNode obj = Json.newObject();
                    obj.put("msg", "deleted");
                    obj.put("freespace", 50 - dvdCount);
//                obj.put("dvdCount",dvdCount);

                    deleteFromCollection(isbn,dvdCollection);

                    return ok(obj);

                }
            }
            return forbidden();
//            return i;
        }
        System.out.println("Invalid ISBN value.....");
        return status(996);
    }

    @Override
    public void displayItems() {
        System.out.println("---Books---");
        for (LibraryItem i:items)
        {
            if (i instanceof Book)
            {
                System.out.println("ISBN :"+i.getW1673657_isbn());
                System.out.println("Type :Book");
                System.out.println("Title :"+i.getW1673657_title());
                System.out.println();
            }
        }
        System.out.println();
        System.out.println("---DVD---");
        for (LibraryItem i:items)
        {
            if (i instanceof DVD)
            {
                System.out.println("ISBN :"+i.getW1673657_isbn());
                System.out.println("Type :DVD");
                System.out.println("Title :"+i.getW1673657_title());
                System.out.println();
            }
        }
    }

    @Override
    public Result borrowItem(String isbn, Reader reader) throws IOException {
        LibraryItem i=find(isbn);

        DateTime now=new DateTime();
        if(i!=null)
        {

            String borrowedDate= mapper.writeValueAsString(now);
            if(i.getReservations().getReservations().size()!=0)
            {
                System.out.println("item has a reservation");
                return status(889);
            }
            else {

                if (i instanceof Book) {
                    if (i.isW1673657_borrowed()) {

                        System.out.println("Book has already borrowed");
                        System.out.println("Available on :" + i.getReturnDate().getTimeDate());
                        return forbidden(Json.toJson("Item has already borrowed,Available on :" + i.getReturnDate().getTimeDate()));
                    } else {

                        i.setBorrowedDetails(now, reader);
                        updateCollection(i, reader, borrowedDate, bookCollection);

                    }
                } else {
                    if (i.isW1673657_borrowed()) {

                        System.out.println("DVD has already borrowed");
                        System.out.println("Available on :" + i.getReturnDate().getTimeDate());
                        return forbidden(Json.toJson("Dvd has already borrowed,Available on :" + i.getReturnDate().getTimeDate()));
                    } else {
                        i.setBorrowedDetails(now, reader);
                        updateCollection(i, reader, borrowedDate, dvdCollection);

                    }
                }
            }
            ObjectNode obj=Json.newObject();
            obj.put("msg","borrowed");
            obj.put("returnDate",i.getReturnDate().getDate());
            return ok(obj);
        }
        return badRequest(Json.toJson("Invalid isbn"));
    }

//    public JSONObject$ j=new JSONObject$();
    @Override
    public Result returnItem(String isbn) throws IOException
    {
        LibraryItem i=find(isbn);
        if(i!=null)
        {
            if(i.isW1673657_borrowed()) {
                i.clearBorrowedDetails();
                if(i instanceof Book)
                    updateCollection(i,null,null,bookCollection);
                else
                    updateCollection(i,null,null,dvdCollection);
                ObjectNode node=Json.newObject();
                node.put("msg","removed");
                return ok(node);

            }
            else
                return badRequest(Json.toJson("item has not borrowed"));
        }
        else
            System.out.println("Invalid ISBN....");
        return notFound(Json.toJson("isbn is not valid"));

    }

    @Override
    public Result getFine(String isbn) {
        double fine;
        int extraHours;
        System.out.println("getFine");
        LibraryItem i=find(isbn);
        if(i!=null)
        {
            if(i.isW1673657_borrowed()) {
                DateTime now = new DateTime();

                extraHours = now.getHours(i.getReturnDate());

                fine = getFine(extraHours);
                if (fine < 0) {
                    fine=0;
                }
                System.out.println("Fine :" + fine);
                HomeController h=new HomeController();
                ObjectNode json=h.getItemAsNode(i);
                json.put("fine",fine);
                return ok(Json.toJson(json));

            }
            else
                return status(997,Json.toJson("item has not borrowed"));
        }
        else
            System.out.println("Invalid ISBN....");
        return notFound(Json.toJson("isbn is not valid"));

    }

    @Override
    public List<OverDueItem> generateReport() {
        List<OverDueItem> overdueList=new ArrayList<>();
        DateTime now=new DateTime();
        for(LibraryItem i:items)
        {
            if(i.isW1673657_borrowed()) {
                int extraHours = now.getHours(i.getReturnDate());
                double fine = getFine(extraHours);
                if (fine > 0)
                    overdueList.add(new OverDueItem(i, fine));
            }
        }
        Collections.sort(overdueList);
        Collections.reverse(overdueList);
        return overdueList;

    }

    @Override
    public LibraryItem find(String isbn)
    {
        for (LibraryItem i: items)
        {
            if(i.getW1673657_isbn().equals(isbn))
                return i;
        }
        return null;
    }

    private double getFine(int extraHours)
    {
        double fine=0;
        if(extraHours>0) {
            if (extraHours > 72) //3 days==72 hours
            {
                fine += 72 * 0.2;
                extraHours -= 72;
                fine += extraHours * 0.5;
            } else {
                fine = extraHours * 0.2;
            }
        }
        return fine;
    }


    public Reader findReader(String readerId)
    {
        int index = readers.indexOf(new Reader(readerId));
        if(index !=-1)
            return readers.get(index);

        return null;
    }

    private void updateCollection(LibraryItem i,Reader r,String d,MongoCollection<Document>collection) throws IOException
    {

        String type="dvd";
        if (i instanceof Book)
            type="book";
        String jsonInString = mapper.writeValueAsString(i);
        System.out.println(jsonInString);
        Bson find = new Document().append("isbn",i.getW1673657_isbn());
        Document updateDvd = new Document()
                .append("isbn", i.getW1673657_isbn())
                .append(type,jsonInString)
                .append("readerId",r==null?null:r.getId())
                .append("borrowedDate",d==null?null:d);
        Bson updateOperationDocument = new Document("$set", updateDvd);
//        System.out.println(updateDvd);
        collection.updateOne(find, updateOperationDocument);

    }

    private void deleteFromCollection(String isbn,MongoCollection<Document>collection) //only for items
    {

        DeleteResult d=collection.deleteOne(Filters.eq("isbn", isbn));
        System.out.println(d.getDeletedCount());
//        if (d.getDeletedCount()==1)
//        collection.deleteOne(d);

    }



    @Override
    public Result updateItem(LibraryItem i)throws IOException
    {
        int index=items.indexOf(i);
        if(index!=-1)
        {
            //update the local array
            items.set(index,i);

            DateTime d=i.getW1673657_borrowedDate();

            String jsonString=mapper.writeValueAsString(d);
            if(i instanceof Book)
            {
                updateCollection(i,i.getW1673657_reader(),jsonString,bookCollection);
            }
            else {
                updateCollection(i,i.getW1673657_reader(),jsonString,dvdCollection);
            }
            ObjectNode obj=Json.newObject();
            obj.put("msg","updated");
            obj.put("bookCount",booksCount);
            obj.put("dvdCount",dvdCount);
            return ok(obj);

        }
        else
        {
           return status(995);
        }

    }

    @Override
    public List<LibraryItem> findItemsByTitle(String title)
    {
        List<LibraryItem>titles=new ArrayList<>();
//        System.out.println("ssss".equals("s"));
        for(LibraryItem i:items)
        {
//            boolean b=i.getW1673657_title().equals(title);
//            System.out.println(b);

            if(i.getW1673657_title().toLowerCase().contains(title.toLowerCase()))
            {
//                System.out.println(i.getW1673657_title()+"   "+title);
                titles.add(i);
            }
        }
        System.out.println(titles);
        return titles;
    }

    @Override
    public Result addReservation(String isbn,String readerId)throws IOException
    {
        LibraryItem i=find(isbn);
        Reader r=findReader(readerId);

        if (i!=null && r!=null)
        {
            boolean x=i.addReservation(r);
            System.out.println(x);
            if(x) {
                ObjectNode obj = Json.newObject();
                obj.put("msg", "updated");

                String borrowedDate = mapper.writeValueAsString(i.getW1673657_borrowedDate());

                if (i instanceof Book)
                    updateCollection(i, i.getW1673657_reader(), borrowedDate, bookCollection);
                return ok(obj);
            }
            else
                return status(888);
        }
        return status(993);
    }

    public Result removeReservation(String isbn,String readerId)throws IOException
    {
        LibraryItem i=find(isbn);
        Reader r=findReader(readerId);

        if (i!=null && r!=null)
        {

                i.removeReservation(r);
                ObjectNode obj=Json.newObject();
                obj.put("msg","removed");

                String borrowedDate= mapper.writeValueAsString(i.getW1673657_borrowedDate());

                if(i instanceof Book)
                    updateCollection(i,i.getW1673657_reader(),borrowedDate,bookCollection);
                else
                    updateCollection(i,i.getW1673657_reader(),borrowedDate,dvdCollection);
                return ok(obj);

        }
        return status(993);
    }



    public Result addReader(Reader r) throws IOException
    {
        int index=readers.indexOf(r);
        if(index == -1) {
            String jsonReader = mapper.writeValueAsString(r);

            Document reader = new Document()
                    .append("readerId", r.getId())
                    .append("reader", jsonReader);

            readerCollection.insertOne(reader);
            readers.add(r);

            ObjectNode obj = Json.newObject();
            obj.put("msg", "added");

            return ok(obj);
        }
        return badRequest();

    }

    public Result updateReader(Reader r)throws IOException
    {
        int index=readers.indexOf(r);

        String jsonString=mapper.writeValueAsString(r);


        Document updateReader = new Document()
                .append("readerId", r.getId())
                .append("reader",jsonString);
        Bson find = new Document().append("readerId",r.getId());
        Bson updateOperationDocument = new Document("$set", updateReader);
        readerCollection.updateOne(find, updateOperationDocument);
        readers.set(index,r);

        ObjectNode obj = Json.newObject();
        obj.put("msg", "updated");

        return ok(obj);

    }

    public Result removeReader(String readerId)throws IOException
    {
        Reader r=findReader(readerId);
        if(r!=null)
        {
            for(LibraryItem i:items)
            {
                if(i.isW1673657_borrowed())
                {
                    if(i.getW1673657_reader().equals(r))
                    {
                        return status(990);
                    }
                }
            }
//            deleteFromCollection(readerId,readerCollection);
            DeleteResult d=readerCollection.deleteOne(Filters.eq("readerId", readerId));
            System.out.println(d.getDeletedCount());

            for(LibraryItem i:items)
            {
                removeReservation(i.getW1673657_isbn(),readerId);
            }
            readers.remove(r);
            ObjectNode obj = Json.newObject();
            obj.put("msg", "removed");

            return ok(obj);

        }
        else
            return notFound();
    }

    public String getReaderId()
    {
        if (readers.size()==0)
            return "1000000";

        long x=Long.parseLong(readers.get(readers.size()-1).getId());
        x++;
        System.out.println(x);
        return String.valueOf(x);
    }






}

// implement another method to find list of books by title (to find the isbn of borrowed books)
