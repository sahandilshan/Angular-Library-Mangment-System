package service;


import models.DateTime;
import models.items.LibraryItem;

public class OverDueItem implements Comparable<OverDueItem>{
    private LibraryItem item;
    private double fine;

    public OverDueItem(LibraryItem i, double fine) {
        this.item = i;
        this.fine = fine;
    }

    public LibraryItem getItem() {
        return item;
    }

    public void setItem(LibraryItem item) {
        this.item = item;
    }

    public double getFine() {
        return fine;
    }

    public void setFine(double fine) {
        this.fine = fine;
    }


    @Override
    public int compareTo(OverDueItem o) {
        if(this.fine-o.fine>0)
            return 1;
        else if(this.fine==o.fine)
            return 0;
        return -1;
//        DateTime now=new DateTime();
//        int cHours=this.item.getW1673657_borrowedDate().getHours(now);
//        int oHours=o.getItem().getW1673657_borrowedDate().getHours(now);
//        return oHours-cHours;

    }
}
