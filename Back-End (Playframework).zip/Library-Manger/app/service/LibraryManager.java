package service;


import models.items.LibraryItem;
import models.persons.Reader;
import play.mvc.Result;

import java.io.IOException;
import java.util.List;

public interface LibraryManager {

    Result addItem(LibraryItem i);
    Result deleteItem(String isbn);
    void displayItems();
    Result getFine(String isbn);
    Result borrowItem(String isbn, Reader reader)throws Exception;
    Result returnItem(String isbn)throws IOException;
    List<OverDueItem> generateReport();
    LibraryItem find(String isbn);
    Reader findReader(String readerId);

    List<LibraryItem> findItemsByTitle(String title);

    Result updateItem(LibraryItem i)throws IOException;


    Result addReservation(String isbn,String readerId)throws IOException;
    Result removeReservation(String isbn,String readerId)throws IOException;

}
